package Pion;

public class PionMain {
    public Pion[] TabP;

    public PionMain(){
        this.TabP = new Pion[1];
        Pion p1 = new Pion("p1");
        p1.set(100,200,100,100);
        
        Pion p2 = new Pion("p2");
        p2.set(100,300,100,100);

        this.TabP[0] = p1;
        // this.TabP[1] = p2;
    }
}
