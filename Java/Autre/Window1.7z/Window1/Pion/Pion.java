package Pion;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;

public class Pion {
    public JLabel Body;
    private String _name;
    private int w=0;
    private int h=0;
    private int x=0;
    private int y=0;
    private int pV=100;
    private String cheminImg = "./Ressource/images/Pion0.jpg";
    private Double distance = 100.0;
    public boolean selected = false;

    public String getName(){
        return _name;
    }
    public void setName(String name) {
        this._name = name;
    }

    public Pion(String name){
        this.Body = new JLabel(); 
        this.setName(name);
        setImage();
        setEvent();
    }
    private void setImage(){
         this.Body.setIcon(new ImageIcon(this.cheminImg));
    }
    private void setEvent(){
        this.Body.addMouseListener(new MouseListener(){
            public void mouseClicked(MouseEvent e) {
                System.out.println("L'image a été cliquée !");
            }
            public void mousePressed(MouseEvent e) {}
            public void mouseReleased(MouseEvent e) {}
            public void mouseEntered(MouseEvent e) {}
            public void mouseExited(MouseEvent e) {}
        });
    }
    public void setPosition(int x, int y){
        this.x = x;
        this.y = y;
        this.Body.setBounds(this.x, this.y, this.w, this.h);
    }
    public void set(int x, int y, int w, int h){
        this.w = w;
        this.h = h;
        this.x = x;
        this.y = y;
        this.Body.setBounds(this.x, this.y, this.w, this.h);
    }
    public void setDimension(int w, int h){
        this.w = w;
        this.h = h;
        this.Body.setBounds(this.x, this.y, this.w, this.h);
    }
    public boolean move(int x, int y){
        Double dist = Math.sqrt(Math.pow(x-this.x,2)+Math.pow(y-this.y,2));
        if(dist <= this.distance){
            this.x = x;
            this.y = y;
            return true;
        }
        else
            return false;
    }
}
