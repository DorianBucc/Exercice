// import javax.swing.*;
import Windows.*;
import Interface.*;
import Pion.*;

public class Start {
    public static void main(String[] args){

        Window1 page1 = new Window1(800,500); // création de la fenetre

        page1.setInterface(new InterfaceMain().TabB);
        page1.setPion(new PionMain().TabP);
        
//-------------------------------------------------------------Fin de Programme
        page1.close(); // définition d'une fermeture propre de la fentere lors d'un clique sur la croix
        page1.Visible(true); // affichage de la fenetre à l'écran
    }
}