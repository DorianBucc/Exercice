package Interface;

import javax.swing.JButton;

public class Bouton {
    public JButton btn;
    
    public Bouton(String msg){
        this.btn = new JButton(msg);
    }
    public void set(int x, int y){
        this.btn.setBounds(x, y,100, 30);
    }
    public void set(int x, int y, int w, int h){
        this.btn.setBounds(x, y, w, h);
    }
}