package Windows;
import Pion.*;
import Interface.*;
import javax.swing.*;

public class Window1 {
    private JFrame Page1;   // Variable de la fenetre
    
    public Window1(int witdh, int height){  // Constructeur
        this.Page1 = new JFrame();  // Création de la fenetre
        this.Page1.setResizable(true);
        //this.Page1.setLayout(null);
        this.Page1.setSize(witdh, height); // Dimension de la fenetre
        this.close();
    }
    
    public void Visible(boolean set){   // Affiché ou non la fenetre
        this.Page1.setVisible(true);
    }

    public void setInterface(Bouton[] TabB){
        for (Bouton bouton : TabB) {
            this.Page1.add(bouton.btn);
        }
    }
    
    public void setPion(Pion[] TabP)
    {
        for (Pion pion : TabP) {
            this.Page1.add(pion.Body);
        }
    }

    public void close(){
        this.Page1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
