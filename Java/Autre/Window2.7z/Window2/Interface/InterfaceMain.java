package Interface;

public class InterfaceMain {
    public Bouton[] Tab;
    public InterfaceMain(){
        this.Tab = new Bouton[1];

        Bouton b1 = new Bouton("Clique"); // création d'un bouton
        b1.set(150,0); // set le posistionement et dimension du bouton
        b1.Body.addActionListener(e -> { // ajout d'un évenement sur le bouton
            System.out.println("Le bouton a été cliqué !");
        });
        this.Tab[0] = b1;
    }
}
