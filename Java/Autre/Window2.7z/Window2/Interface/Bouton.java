package Interface;

import javax.swing.JButton;

public class Bouton {
    public JButton Body;
    
    public Bouton(String msg){
        this.Body = new JButton(msg);
    }
    public void set(int x, int y){
        this.Body.setBounds(x, y,100, 30);
    }
    public void set(int x, int y, int w, int h){
        this.Body.setBounds(x, y, w, h);
    }
}