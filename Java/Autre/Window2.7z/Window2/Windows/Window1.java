package Windows;
import Interface.*;
import Label.*;
import Text.*;
import javax.swing.*;

public class Window1 {
    private JFrame Body;   // Variable de la fenetre
    
    public Window1(String Titre, int witdh, int height){  // Constructeur
        this.Body = new JFrame(Titre);  // Création de la fenetre
        this.Body.setResizable(true);
        this.Body.setLayout(null);
        this.Body.setSize(witdh, height); // Dimension de la fenetre
        this.close(); // définition d'une fermeture propre de la fentere lors d'un clique sur la croix
    }
    
    public void Visible(boolean set){   // Affiché ou non la fenetre
        this.Body.setVisible(set);
    }

    public void setInterface(Bouton[] Tab){
        for (Bouton bouton : Tab) {
            this.Body.add(bouton.Body);
        }
    }
    public void setLabel(Label[] Tab){
        for (Label label : Tab) {
            this.Body.add(label.Body);
        }
    }
    public void setText(TextMain TM){
        for (int j = 0; j < TM.Tab.length; j++) {
            if(TM.Tab[j].Type == 1){
                this.Body.add(TM.Tab[j].Area);
            }
            else if(TM.Tab[j].Type == 2){
                this.Body.add(TM.Tab[j].Field);
            }
        }
    }

    public void close(){
        this.Body.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
