package Windows;
import javax.swing.*;

public class Window2 {
    public Window2(){
        JFrame Page1 = new JFrame();
        Page1.setVisible(true);
        Page1.setSize(1000, 400);
    }
}
