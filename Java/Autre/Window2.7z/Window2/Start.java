// import javax.swing.*;
import Windows.*;
import Interface.InterfaceMain;
import Label.LabelMain;
import Text.TextMain;

public class Start {
    public static void main(String[] args){

        Window1 page1 = new Window1("Accueil",400,600); // création de la fenetre

        page1.setInterface(new InterfaceMain().Tab);
        page1.setLabel(new LabelMain().Tab);
        page1.setText(new TextMain());
        
//-------------------------------------------------------------Fin de Programme
        page1.Visible(true); // affichage de la fenetre à l'écran
    }
}