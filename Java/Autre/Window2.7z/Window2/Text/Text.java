package Text;

import javax.swing.JTextArea;
import javax.swing.JTextField;


public class Text {
    public JTextArea Area; // corps de l'objet
    public JTextField Field; // corps de l'objet
    public int Type;        // type du corps de l'objet

    private int x = 0;  // position de x
    private int y = 0;   // position de y
    private int w = 100; // largeur (witdh)
    private int h = 30;  // hauteur (height)
    
    public int getType() { return Type; }
    
    public Text(String Area_Field, String text){
        if(Area_Field == "Area"){
            this.Type = 1;
            this.Area = new JTextArea();
            this.Area.setText(text);
        }
        else if(Area_Field == "Field"){
            this.Type = 2;
            this.Field = new JTextField();
            this.Field.setText(text);
        }
        else
        throw new Error("Probleme class Text(Type inexistant)");
    }

    public void setPosition(int x, int y){
        this.x = x;
        this.y = y;
        this.setB();
    }
    public void set(int x,int y, int w, int h){
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.setB();
    }
    public void setSize(int w, int h){
        this.w = w;
        this.h = h;
        this.setB();
    }

    private void setB(){
        if(this.Type == 1){
            this.Area.setBounds(this.x, this.y,this.w, this.h);
        }
        else if(this.Type == 2){
            this.Field.setBounds(this.x, this.y,this.w, this.h);
        }
    }
}
