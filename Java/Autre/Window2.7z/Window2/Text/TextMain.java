package Text;

public class TextMain {
     public Text[] Tab;

     public TextMain(){
        this.Tab = new Text[2];
        
        Text t1 = new Text("Area", "Test Text");
        t1.set(100, 300, 100, 30);

        this.Tab[0] = t1;

        Text t2 = new Text("Field", "ya R");
        t2.set(100, 400, 100, 30);
        this.Tab[1] = t2;

     }

     
}
