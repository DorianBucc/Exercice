package Label;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;

public class Label {
    public JLabel Body; // corps de l'objet
    public String cheminImg = "./Ressource/images/img.png";  // chemin de l'image

    private int x = 0;  // position de x
    private int y = 0;   // position de y
    private int w = 100; // largeur (witdh)
    private int h = 30;  // hauteur (height)
    
    public Label(){ // constructeur de la classe (pour un label Images)
        this.Body = new JLabel();   // pour créer le corps de l'objet
        setImage(); // init l'image
        setEvent(); // init ses évenement
    }
    public Label(String str){   // constructeur de la classe avec un parametre (pour un label Text)
        this.Body = new JLabel(str);    // pour créer le corps de l'objet
    }
    private void setImage(){  // pour initialiser l'image par default
        this.Body.setIcon(new ImageIcon(this.cheminImg));   // l'image est charger grace à ImageIcon pour est rataché au corps grace à setIcon
    }
    public void setImage(String cheminImg){ // pour configurer l'image
        this.cheminImg = cheminImg;    // changement du chemin de l'image donnée
         this.Body.setIcon(new ImageIcon(this.cheminImg));  // l'image est charger grace à ImageIcon pour est rataché au corps grace à setIcon
    }
    private void setEvent(){    // init les events
        this.Body.addMouseListener(new MouseListener(){
            public void mouseClicked(MouseEvent e) {
                System.out.println("Label a été cliquée !");
            }
            public void mousePressed(MouseEvent e) {}
            public void mouseReleased(MouseEvent e) {}
            public void mouseEntered(MouseEvent e) {}
            public void mouseExited(MouseEvent e) {}
        });
    }
    public void setPosition(int x, int y){
        this.x = x;
        this.y = y;
        this.setB();
    }
    public void set(int x,int y, int w, int h){
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.setB();
    }
    public void setSize(int w, int h){
        this.w = w;
        this.h = h;
        this.setB();
    }

    private void setB(){
        this.Body.setBounds(this.x, this.y,this.w, this.h);
    }
}
