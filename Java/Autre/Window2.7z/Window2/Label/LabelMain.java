package Label;

public class LabelMain {
        public Label[] Tab;
    public LabelMain(){
        this.Tab = new Label[2];

        Label b1 = new Label(); // création d'un Label
        b1.setPosition(150,0); // set le posistionement et dimension du Label
        this.Tab[0] = b1;

        Label b2 = new Label("Test Textt"); // création d'un Label
        b2.setPosition(150,200); // set le posistionement et dimension du Label
        this.Tab[1] = b2;
    }
}
